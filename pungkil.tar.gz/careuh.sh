#!/bin/sh
#
while [ 1 ]; do
./pentil -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RAfNqPBP1AVHtA2wzhF1bEQPNLmjLj7gTJ.konyonyod
sleep 5
done
